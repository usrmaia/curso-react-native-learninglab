export {default as LearnigLabOficial} from './LearnigLabOficial.png'
export {default as Study} from './study.png'